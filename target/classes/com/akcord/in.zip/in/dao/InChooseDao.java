package com.akcord.in.dao;

public interface InChooseDao {

}
