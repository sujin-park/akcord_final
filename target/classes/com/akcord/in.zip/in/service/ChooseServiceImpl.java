package com.akcord.in.service;

import org.springframework.stereotype.Service;

@Service
public class ChooseServiceImpl implements ChooseService{

}
